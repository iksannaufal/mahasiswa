<?php
 header("Access-Control-Allow-Origin: *");
 $koneksi = mysqli_connect("localhost","root","","mahasiswa") or die ("could not connect database");
?>
